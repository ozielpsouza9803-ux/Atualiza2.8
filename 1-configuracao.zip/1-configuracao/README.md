<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Corações que Acolhe - Lar Esperança

PWA de apadrinhamento de crianças do Lar Esperança, com doações, painel administrativo, galeria e perfis. Criado no Google AI Studio.

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/2b24445d-4135-48a3-a9b0-348326bbec05

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Copie `.env.example` para `.env` e preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` com a chave publishable do seu projeto Supabase
3. Run the app:
   `npm run dev`
